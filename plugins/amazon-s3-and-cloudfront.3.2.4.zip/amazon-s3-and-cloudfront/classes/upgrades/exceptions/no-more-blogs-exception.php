<?php

namespace DeliciousBrains\WP_Offload_Media\Upgrades\Exceptions;

class No_More_Blogs_Exception extends \Exception {
}
