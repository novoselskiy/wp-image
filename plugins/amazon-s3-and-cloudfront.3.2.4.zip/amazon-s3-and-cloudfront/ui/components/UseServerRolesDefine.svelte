<script>
	export let provider;
</script>

<p>{@html provider.use_server_roles_desc}</p>

<pre>{provider.use_server_roles_example}</pre>