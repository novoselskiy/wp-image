<script>
	import {strings} from "../js/stores";
</script>

<p>{$strings.loading}</p>