<script>
	export let provider;
</script>

<p>{@html provider.define_key_file_desc}</p>

<pre>{provider.define_key_file_example}</pre>
